"""Lab_kedro
"""

__version__ = "0.1"
