"""
This is a boilerplate pipeline 'train_model'
generated using Kedro 0.18.11
"""
