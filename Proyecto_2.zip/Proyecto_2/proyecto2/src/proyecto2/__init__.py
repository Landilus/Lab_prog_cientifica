"""proyecto2
"""

__version__ = "0.1"
